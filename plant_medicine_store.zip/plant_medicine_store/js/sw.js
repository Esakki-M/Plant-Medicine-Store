// Service Worker module for Plant Medicine Store

/**
 * Set up the service worker for Progressive Web App functionality
 */
export function setupServiceWorker() {
    console.log('Setting up service worker');
    
    // Check if service worker is supported
    if ('serviceWorker' in navigator) {
        // Register the service worker with the correct path
        navigator.serviceWorker.register('./service-worker.js')
            .then(registration => {
                console.log('Service Worker registered with scope:', registration.scope);
            })
            .catch(error => {
                console.error('Service Worker registration failed:', error);
            });
    } else {
        console.warn('Service Workers are not supported in this browser');
    }
}

/**
 * Create and configure a service worker
 * This would typically be in a separate service-worker.js file
 * For this implementation, we're just providing the setup function
 */
if (false) { // This code is for reference only and won't execute
    // Service worker installation
    self.addEventListener('install', event => {
        event.waitUntil(
            caches.open('plant-medicine-v1').then(cache => {
                return cache.addAll([
                    '/',
                    '/index.html',
                    '/products.js',
                    '/js/analytics.js',
                    '/js/sw.js',
                    // Add other important assets to cache
                ]);
            })
        );
    });

    // Service worker activation (cleanup old caches)
    self.addEventListener('activate', event => {
        event.waitUntil(
            caches.keys().then(cacheNames => {
                return Promise.all(
                    cacheNames.filter(cacheName => {
                        return cacheName !== 'plant-medicine-v1';
                    }).map(cacheName => {
                        return caches.delete(cacheName);
                    })
                );
            })
        );
    });

    // Fetch handler for network requests
    self.addEventListener('fetch', event => {
        event.respondWith(
            caches.match(event.request).then(response => {
                // Return cached response if found
                if (response) {
                    return response;
                }
                
                // Otherwise fetch from network
                return fetch(event.request).then(response => {
                    // Don't cache if not a valid response
                    if (!response || response.status !== 200 || response.type !== 'basic') {
                        return response;
                    }
                    
                    // Clone the response
                    const responseToCache = response.clone();
                    
                    // Add to cache for future use
                    caches.open('plant-medicine-v1').then(cache => {
                        cache.put(event.request, responseToCache);
                    });
                    
                    return response;
                });
            })
        );
    });
}