// Analytics module for Plant Medicine Store

/**
 * Initialize analytics tracking for the website
 */
export function initializeAnalytics() {
    console.log('Analytics initialized');
    
    // Track page views
    trackPageView();
    
    // Set up event listeners for important user interactions
    setupEventTracking();
}

/**
 * Track page views
 */
function trackPageView() {
    const pageData = {
        title: document.title,
        url: window.location.href,
        referrer: document.referrer,
        timestamp: new Date().toISOString()
    };
    
    console.log('Page view tracked:', pageData);
    
    // In a real implementation, you would send this data to your analytics service
    // Example: sendToAnalyticsService('pageview', pageData);
}

/**
 * Set up event tracking for important user interactions
 */
function setupEventTracking() {
    // Track product views
    document.querySelectorAll('.product-card').forEach(card => {
        card.addEventListener('click', () => {
            const productName = card.querySelector('.card-title')?.textContent;
            if (productName) {
                trackEvent('product_view', { product_name: productName });
            }
        });
    });
    
    // Track add to cart events
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent triggering the product view event
            const productId = button.dataset.productId;
            const productName = button.closest('.product-card')?.querySelector('.card-title')?.textContent;
            
            if (productId && productName) {
                trackEvent('add_to_cart', { 
                    product_id: productId,
                    product_name: productName
                });
            }
        });
    });
    
    // Track search events
    const searchInput = document.getElementById('searchProducts');
    if (searchInput) {
        let debounceTimer;
        searchInput.addEventListener('input', () => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                const query = searchInput.value.trim();
                if (query) {
                    trackEvent('search', { query });
                }
            }, 1000); // Track after 1 second of inactivity
        });
    }
}

/**
 * Track a custom event
 * @param {string} eventName - Name of the event
 * @param {Object} eventData - Data associated with the event
 */
function trackEvent(eventName, eventData = {}) {
    const eventInfo = {
        event: eventName,
        data: eventData,
        timestamp: new Date().toISOString()
    };
    
    console.log('Event tracked:', eventInfo);
    
    // In a real implementation, you would send this data to your analytics service
    // Example: sendToAnalyticsService('event', eventInfo);
}

/**
 * Send data to analytics service (placeholder function)
 * @param {string} type - Type of analytics data (pageview, event, etc.)
 * @param {Object} data - The data to send
 */
function sendToAnalyticsService(type, data) {
    // This would be implemented to send data to Google Analytics, Mixpanel, etc.
    console.log(`[Analytics] Would send ${type} data to analytics service:`, data);
}